package com.genuinecoder.dog.repository;

import com.genuinecoder.dog.entity.SightingBoard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SightingBoardRepository extends JpaRepository<SightingBoard, Long> {
}
