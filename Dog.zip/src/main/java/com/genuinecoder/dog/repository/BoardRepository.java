package com.genuinecoder.dog.repository;

import com.genuinecoder.dog.entity.Board;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BoardRepository extends JpaRepository<Board, Long> {
}
