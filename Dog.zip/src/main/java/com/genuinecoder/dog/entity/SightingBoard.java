package com.genuinecoder.dog.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity // JPA 객체와 테이블 매핑
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SightingBoard { // 기존에 Observe
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // 변경

    private String title; // 변경
    private String username; // 추가
    private String breed; // 변경
    private String size; // 변경
    private String color; // 변경
    private String characteristics; // 변경
    private String lastSeenLocation; // 변경
    private String lastSeenTime; // 변경
    private String contact; // 변경
    private String additionalInfo; // 변경
    private LocalDateTime createdAt; // 추가

    @ManyToOne // 추가
    private User user; // 추가

    @PrePersist // 추가
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "SightingBoard{" +
                "title='" + title + '\'' +
                ", bread='" + breed + '\'' +
                ", size='" + size + '\'' +
                ", color='" + color + '\'' +
                ", characteristics='" + characteristics + '\'' +
                ", lastSeenLocation='" + lastSeenLocation + '\'' +
                ", lastSeenTime='" + lastSeenTime + '\'' +
                ", contact='" + contact + '\'' +
                ", additionalInfo='" + additionalInfo + '\'' +
                ", username='" + username + '\'' + // 추가
                ", createdAt='" + createdAt + '\'' + // 추가
                ", user='" + user.getName() + '\'' + // 추가 (user가 null이 아닐 때만 사용)
                '}';
    }
}
