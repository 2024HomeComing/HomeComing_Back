package com.genuinecoder.dog.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class Board { // 기존에 Report
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // 변경

    private String username; // 추가
    private String age; // 변경

    private String title; // 변경
    private String size; // 변경
    private String name; // 변경
    private String characteristics; // 변경
    private String color; // 변경
    private String breed; // 변경
    private String lastSeenLocation; // 변경
    private String lastSeenTime; // 변경
    private String contact; // 변경
    private String additionalInfo; // 변경
    private LocalDateTime createdAt; // 추가

    private String imageUrl; // 추가

    @ManyToOne // 추가
    private User user; // 추가

    @PrePersist // 추가
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "Board{" +
                "title='" + title + '\'' +
                ", breed='" + breed + '\'' +
                ", name='" + name + '\'' +
                ", size='" + size + '\'' +
                ", age=" + age +
                ", color='" + color + '\'' +
                ", characteristics='" + characteristics + '\'' +
                ", lastSeenLocation='" + lastSeenLocation + '\'' +
                ", lastSeenTime='" + lastSeenTime + '\'' +
                ", contact='" + contact + '\'' +
                ", additionalInfo='" + additionalInfo + '\'' +
                ", username='" + username + '\'' + // 추가
                ", createdAt='" + createdAt + '\'' + // 추가
                ", imageUrl='" + imageUrl + '\'' + // 추가
                ", user='" + user.getName() + '\'' + // 추가 (user가 null이 아닐 때만 사용)
                '}';
    }
}
