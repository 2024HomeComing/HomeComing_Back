package com.genuinecoder.dog.service;

import com.genuinecoder.dog.entity.Board;
import com.genuinecoder.dog.entity.SightingBoard;
import com.genuinecoder.dog.repository.BoardRepository;
import com.genuinecoder.dog.repository.SightingBoardRepository;
import com.genuinecoder.dog.util.TfIdfCalculator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class PetService {
    private static final Logger logger = LoggerFactory.getLogger(PetService.class);

    private final BoardRepository boardRepository;
    private final SightingBoardRepository sightingBoardRepository;
    private final Set<String> stopWords;
    private final TfIdfCalculator tfIdfCalculator;

    @Autowired
    public PetService(BoardRepository boardRepository, SightingBoardRepository sightingBoardRepository) throws IOException {
        this.boardRepository = boardRepository;
        this.sightingBoardRepository = sightingBoardRepository;
         this.stopWords = Files.lines(Paths.get("src/main/resources/stopword.txt"))
                 .map(String::trim)
                 .collect(Collectors.toSet());
        this.tfIdfCalculator = new TfIdfCalculator(new HashSet<>()); // 빈 Set 전달
    }

    public String findBestMatch(Long boardId) {
        // 해당 ID의 신고글을 가져옵니다.
        Board board = boardRepository.findById(boardId).orElse(null);
        if (board == null) {
            return "해당 ID의 신고글을 찾을 수 없습니다.";
        }

        logger.info("신고글: {}", board);

        // 데이터베이스에서 모든 목격글을 가져옵니다.
        List<SightingBoard> sightings = sightingBoardRepository.findAll();
        logger.info("목격글 목록: {}", sightings);

        // 신고글의 breed와 동일한 breed의 목격글들만 필터링합니다.
        List<SightingBoard> filteredSightings = sightings.stream()
                .filter(sighting -> sighting.getBreed().equals(board.getBreed()))
                .collect(Collectors.toList());

        logger.info("필터링된 목격글 목록: {}", filteredSightings);

        if (filteredSightings.isEmpty()) {
            return "매칭된 결과가 없습니다.1";
        }

        // 신고글의 텍스트를 결합하여 TF-IDF 벡터를 계산합니다.
        String boardText = concatenateFields(board);
        logger.info("신고글 텍스트: {}", boardText);

        List<String> sightingTexts = filteredSightings.stream()
                .map(this::concatenateFields)
                .collect(Collectors.toList());
        logger.info("목격글 텍스트 목록: {}", sightingTexts);

        Map<String, Double> idfMap = tfIdfCalculator.computeIdf(sightingTexts);
        logger.info("IDF Map: {}", idfMap);

        Map<String, Double> boardTfIdfVector = tfIdfCalculator.computeTfIdf(boardText, idfMap);
        logger.info("Board TF-IDF Vector: {}", boardTfIdfVector);

        // 가장 잘 매칭된 목격글을 저장할 변수를 초기화합니다.
        SightingBoard bestSighting = null;
        double maxSimilarity = 0.0;

        // 신고글과 필터링된 목격글들을 비교하여 가장 유사한 목격글을 찾습니다.
        for (SightingBoard sighting : filteredSightings) {
            String sightingText = concatenateFields(sighting);
            logger.info("목격글 텍스트: {}", sightingText);

            Map<String, Double> sightingTfIdfVector = tfIdfCalculator.computeTfIdf(sightingText, idfMap);
            logger.info("Sighting TF-IDF Vector: {}", sightingTfIdfVector);

            double similarity = tfIdfCalculator.cosineSimilarity(boardTfIdfVector, sightingTfIdfVector);
            logger.info("Similarity with Sighting [{}]: {}", sighting.getId(), similarity);

            if (similarity > maxSimilarity) {
                maxSimilarity = similarity;
                bestSighting = sighting;
            }
        }

        // 가장 많이 매칭된 신고글과 목격글 쌍을 반환합니다.
        if (bestSighting != null) {
            return String.format("가장 잘 매칭된 신고글과 목격글:<br>신고글: %s<br>목격글: %s<br>유사도: %.2f",
                    board.toString().replace(",", "<br>"), bestSighting.toString().replace(",", "<br>"), maxSimilarity);
        } else {
            return "매칭된 결과가 없습니다.2";
        }
    }

    private String concatenateFields(Board board) {
        return String.join(" ",
                board.getTitle(),
                board.getBreed(),
                board.getSize(),
                board.getColor(),
                board.getCharacteristics(),
                board.getLastSeenLocation());
    }

    private String concatenateFields(SightingBoard sightingBoard) {
        return String.join(" ",
                sightingBoard.getTitle(),
                sightingBoard.getBreed(),
                sightingBoard.getSize(),
                sightingBoard.getColor(),
                sightingBoard.getCharacteristics(),
                sightingBoard.getLastSeenLocation());
    }
}
